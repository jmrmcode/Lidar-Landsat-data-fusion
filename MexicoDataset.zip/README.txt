﻿This README.txt file was generated on 2019/10/08 by Juan Miguel Requena Mullor

-------------------
GENERAL INFORMATION
-------------------

Title of Dataset: Lidar-derived canopy height data and Landsat-derived vegetation indices for the G-LiHT NASA acquisitions in Mexico

Author Information (Juan Miguel Requena Mullor, Boise State University, 1910 W University Dr, Boise, ID 83725, juanmimullor@gmail.com)

	Principal Investigator: Juan Miguel Requena Mullor
	Co-investigator: T. Trevor Caughlin

Date of data collection: from 2013-04-01 to 2013-05-31

Geographic location of data collection: Mexico 

Information about funding sources or sponsorship that supported the collection of the data: AI for Earth Grant from Microsoft (https://www.microsoft.com/en-us/ai/ai-for-earth)


--------------------------
SHARING/ACCESS INFORMATION
-------------------------- 

Licenses/restrictions placed on the data, or limitations of reuse: GNU GENERAL PUBLIC LICENSE; Version 3, 29 June 2007 (https://github.com/jmrmcode/Lidar-Landsat-data-fusion/blob/master/LICENSE)


--------------------
DATA & FILE OVERVIEW
--------------------

Files list: MexicoDataset.csv

Sources list: G-LiHT NASA (https://glihtdata.gsfc.nasa.gov/), Amazon Web Services (https://registry.opendata.aws/landsat-8/), Google Earth Engine (https://earthengine.google.com/)

Date of creation: 2019-10-08


--------------------------
METHODOLOGICAL INFORMATION
--------------------------

Description of methods used for collection/generation of data: https://github.com/jmrmcode/Lidar-Landsat-data-fusion

Software needed to interpret the data: R version 3.6.0 (2019-04-26) -- "Planting of a Tree" 

People involved with sample collection, processing, and submission: Juan Miguel Requena Mullor


--------------------------
DATA-SPECIFIC INFORMATION <Create sections for each datafile or set, as appropriate>
--------------------------

Number of variables: 8

Number of cases/rows: 808,000

Variable list:

		X: unique ID for each 1x1 m pixel
		CanopyHeight: Canopy height in meters
		EVI: Enhanced Vegetation Index
		NDVI: Normalized Difference Vegetation Index
		NDWI: Normalized Difference Water Index
		Ecoregion: unique label for each Mexico ecoregion
		ID_G_LiTH_Plot: unique ID for each G-LiHT sampling site
		ID_LandsatPixel: unique ID for each Landsat pixel
   
Missing data code: NA